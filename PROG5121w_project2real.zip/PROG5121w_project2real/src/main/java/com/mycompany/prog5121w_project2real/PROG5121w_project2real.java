/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121w_project2real;

import java.util.Random;

/**
 *
 * @author Kulani
 */
public class PROG5121w_project2real {

    public static void main(String[] args) {
        import java.util.Random;
import java.util.Scanner;

public class QuickChat {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        boolean loggedIn = true; 
        int totalSent = 0;
        int messageNumber = 0;

        if (loggedIn) {

            System.out.println("Welcome to QuickChat.");

            while (true) {

                System.out.println("\n===== QUICKCHAT MENU =====");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Quit");
                System.out.print("Choose an option: ");

                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {

                    case 1:

                        System.out.print("How many messages would you like to send? ");
                        int numMessages = scanner.nextInt();
                        scanner.nextLine();

                        for (int i = 0; i < numMessages; i++) {

                            messageNumber++;

                            // Generate random 10-digit Message ID
                            long messageID = 1000000000L +
                                    (long) (random.nextDouble() * 9000000000L);

                            // Recipient
                            System.out.print("\nEnter recipient number: ");
                            String recipient = scanner.nextLine();

                            if (recipient.length() <= 10 && recipient.startsWith("+")) {
                                System.out.println("Cell phone number successfully captured.");
                            } else {
                                System.out.println("Cell phone number incorrectly formatted.");
                                continue;
                            }

                            // Message
                            System.out.print("Enter your message: ");
                            String message = scanner.nextLine();

                            if (message.length() > 250) {

                                System.out.println(
                                        "Please enter a message of less than 250 characters.");

                            } else {

                                System.out.println("Message ready to send.");

                                // Create Message Hash
                                String[] words = message.split(" ");

                                String firstWord = words[0].toUpperCase();
                                String lastWord = words[words.length - 1].toUpperCase();

                                String hash =
                                        String.valueOf(messageID).substring(0, 2)
                                                + ":" + messageNumber
                                                + ":" + firstWord + lastWord;

                                // Options
                                System.out.println("\nChoose an option:");
                                System.out.println("1) Send Message");
                                System.out.println("2) Discard Message");
                                System.out.println("3) Store Message");

                                int action = scanner.nextInt();
                                scanner.nextLine();

                                switch (action) {

                                    case 1 -> {
                                        totalSent++;

                                        System.out.println("\nMessage successfully sent.");

                                        System.out.println("\n===== MESSAGE DETAILS =====");
                                        System.out.println("Message ID: " + messageID);
                                        System.out.println("Message Hash: " + hash);
                                        System.out.println("Recipient: " + recipient);
                                        System.out.println("Message: " + message);
                                    }

                                    case 2 -> {
                                        System.out.println("Press 0 to delete message.");
                                        int delete = scanner.nextInt();
                                        scanner.nextLine();

                                        if (delete == 0) {
                                            System.out.println("Message discarded.");
                                        }
                                    }

                                    case 3 -> {
                                        System.out.println("Message successfully stored.");
                                        
                                        
                                        String json = "{"
                                                + "\"MessageID\":\"" + messageID + "\","
                                                + "\"Recipient\":\"" + recipient + "\","
                                                + "\"Message\":\"" + message + "\""
                                                + "}";

                                        System.out.println("Stored JSON:");
                                        System.out.println(json);
                                    }

                                    default -> System.out.println("Invalid option.");
                                }
                            }
                        }

                        System.out.println("\nTotal messages sent: " + totalSent);

                        break;

                    case 2:

                        System.out.println("Coming Soon.");
                        break;

                    case 3:

                        System.out.println("Goodbye!");
                        scanner.close();
                        System.exit(0);

                    default:

                        System.out.println("Invalid option.");
                }
            }

        } else {

            System.out.println("Please login first.");
        }
    }
}

import java.util.Scanner;
import java.util.Random;

final class Message {

   
    String messageID;
    String recipient;
    String message;
    String messageHash;

    static int totalMessages = 0;

    public Message(String recipient, String message) {
        this.recipient = recipient;
        this.message = message;

        Random rand = new Random();
        messageID = String.valueOf(100000000 + rand.nextInt(900000000));

        messageHash = createMessageHash();
    }

    public boolean checkMessageID() {

        return messageID.length() <= 10;
    }

    public String checkRecipientCell() {

        if (recipient.startsWith("+") && recipient.length() <= 13) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted.";
        }
    }

    public String createMessageHash() {

        String[] words = message.split(" ");

        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();

        return messageID.substring(0, 2) + ":0:" + firstWord + lastWord;
    }

    public String sentMessage(int choice) {

        switch (choice) {
            case 1 -> {
                totalMessages++;
                return "Message successfully sent.";
            }
            case 2 -> {
                return "Message successfully stored.";
            }
            case 3 -> {
                return "Press 0 to delete the message.";
            }
            default -> {
                return "Invalid choice.";
            }
        }
    }

    public void printMessages() {

        System.out.println("Message ID: " + messageID);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + message);
        System.out.println("Message Hash: " + messageHash);
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }
}

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of messages: ");
        int numMessages = input.nextInt();
        input.nextLine();
        
        for (int i = 0; i < numMessages; i++) {

            System.out.println("\nMessage " + (i + 1));

            System.out.print("Enter recipient number: ");
            String recipient;
            recipient = input.nextLine();

            System.out.print("Enter message: ");
            String text;
            text = input.nextLine();

            Message msg;
            msg = new Message(recipient, text);


            if (text.length() <= 250) {
                System.out.println("Message ready to send.");
            } else {
                int extra = text.length() - 250;
                System.out.println("Message exceeds 250 characters by " + extra);
            }

            System.out.println(msg.checkRecipientCell());

            if (msg.checkMessageID()) {
                System.out.println("Message ID generated: " + msg.messageID);
            }

            System.out.println("Message Hash: " + msg.messageHash);

            System.out.println("\n1. Send Message");
            System.out.println("2. Store Message");
            System.out.println("3. Disregard Message");

            System.out.print("Choose option: ");
            int option = input.nextInt();
            input.nextLine();

            System.out.println(msg.sentMessage(option));

            msg.printMessages();

            System.out.println("Total messages sent: "
                    + Message.returnTotalMessages());
        }

        input.close();
    }
}
    }

